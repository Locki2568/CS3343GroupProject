package IntegrationTest;
import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Test;

import SourceCode.ImportInformation;

public class IntagrationTest {

	@Test //This is integration test
	public void testImportInformation01() throws Exception
	{	
		// User input : false, false, false, false, 500
		ImportInformation information = new ImportInformation();
		information.importMenu("Food_Data_Test1");
		information.importUserInput();
		String expectedOutput = "Invalid input, please choose at least one type of food.";
		setOutput();
		information.validateInput();
		information.setupMenu();
		assertEquals(expectedOutput, getOutput());
	}

	@Test //This is integration test
	public void testImportInformation02() throws Exception
	{	
		// User input : false, false, true, false, 0
		ImportInformation information = new ImportInformation();
		information.importMenu("Food_Data_Test1");
		information.importUserInput();
		String expectedOutput = "Invalid input, the bugget should be greater than zero.";
		setOutput();
		information.validateInput();
		information.setupMenu();
		assertEquals(expectedOutput, getOutput());
	}

	@Test //This is integration test
	public void testImportInformation03() throws Exception
	{	
		// User input : false, false, false, true, 250
		ImportInformation information = new ImportInformation();
		information.importMenu("Food_Data_Test1");
		information.importUserInput();
		String expectedOutput = "Import user input complete.";
		setOutput();
		information.validateInput();
		information.setupMenu();
		assertEquals(expectedOutput, getOutput());
	}
	
	@Test //This is integration test
	public void testImportInformation04() throws Exception
	{	
		// User input : true, true, false, false, 300
		ImportInformation information = new ImportInformation();
		information.importMenu("Food_Data_Test1");
		information.importUserInput();
		String expectedOutput = "Import user input complete.";
		setOutput();
		information.validateInput();
		information.setupMenu();
		assertEquals(expectedOutput, getOutput());
	}
	
	@Test //This is integration test
	public void testImportInformation05() throws Exception
	{	
		// User input : false, true, true, true, 200
		ImportInformation information = new ImportInformation();
		information.importMenu("Food_Data_Test1");
		information.importUserInput();
		String expectedOutput = "Import user input complete.";
		setOutput();
		information.validateInput();
		information.setupMenu();
		assertEquals(expectedOutput, getOutput());
	}

	@After
	public void after() throws Exception
	{
		System.out.println("Running: tearDown");
		ImportInformation.resetAllInformation();
		clearOutput();
	}

	PrintStream oldPrintStream;
	ByteArrayOutputStream bos;

	private void setOutput() throws Exception {
		oldPrintStream = System.out;
		bos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(bos));
	}

	private void clearOutput()
	{
		oldPrintStream = null;
		bos = null;
	}

	private String getOutput() { // throws Exception
		System.setOut(oldPrintStream);
		return bos.toString().trim();
	}
}

